#ifndef THREEDPLOT_H
#define THREEDPLOT_H


class ThreeDPlot
{
    public:
        double xi,xf;
        int Nx;
        double yi,yf;
        int Ny;
        double** x,**y;
        ThreeDPlot();
        ThreeDPlot(double,double,int,double,double,int);
        virtual ~ThreeDPlot();

    protected:

    private:
};

#endif // THREEDPLOT_H

#include <iostream>
#include "ThreeDPlot.h"
#include <iomanip>
#include <cmath>
#include "TCanvas.h"
#include "TGraph2DErrors.h"
#include "TStyle.h"

using namespace std;

int main()
{
    double pi=3.14159265358979;
    ThreeDPlot tdp(-pi,pi,20,-pi,pi,20);
    double ** z=new double*[tdp.Nx+1];
    for(int i=0;i<tdp.Nx+1;i++)
    {
        z[i]=new double[tdp.Ny+1];
    }
    for(int i=0;i<=tdp.Nx;i++)
    {
        for(int j=0;j<tdp.Ny;j++)
        {
            z[i][j]=sin(tdp.x[i][j])*cos(tdp.y[i][j]);
        }
    }
    int n=(tdp.Nx+1)*(tdp.Ny+1),m=0;
    TCanvas *c1 = new TCanvas();
    gStyle->SetPalette(1);
    TGraph2DErrors tdg(n);
    for(int i=0;i<=tdp.Nx;i++)
    {
        for(int j=0;j<=tdp.Ny;j++)
        {
            tdg.SetPoint(m++,tdp.x[i][j],tdp.y[i][j],z[i][j]);
        }
    }
    tdg.Draw("surf6");
    //gPad->Update();
    c1->Print("RW.eps");

    for(int i=0;i<tdp.Nx+1;i++)
    {
        delete[] z[i];
    }
    delete[] z;
    return 0;
}

#include "ThreeDPlot.h"

ThreeDPlot::ThreeDPlot()
{
    //ctor
}
ThreeDPlot::ThreeDPlot(double x0,double x1,int nx,double y0,double y1,int ny): xi(x0),xf(x1),Nx(nx),yi(y0),yf(y1),Ny(ny)
{
    x=new double*[Nx+1];
    y=new double*[Nx+1];
    for(int i=0;i<Nx+1;i++)
    {
        x[i]=new double[Ny+1];
        y[i]=new double[Ny+1];
    }
    double dx=(xf-xi)/Nx;
    double dy=(yf-yi)/Ny;
    for(int i=0;i<Nx+1;i++)
    {
        for(int j=0;j<Ny+1;j++)
        {
            x[i][j]=xi+i*dx;
            y[i][j]=yi+j*dy;
        }
    }
}

ThreeDPlot::~ThreeDPlot()
{
    for(int i=0;i<Nx;i++)
    {
        delete[] x[i];
        delete[] y[i];
    }
    delete[] x;
    delete[] y;
}

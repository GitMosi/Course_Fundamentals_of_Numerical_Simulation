function Y=RanMInt(x0,xn)
N=100;
dx=(xn-x0);
x=rand(1,N).*dx+x0;
Y=func(x);
Y=dx.*sum(Y)./N;
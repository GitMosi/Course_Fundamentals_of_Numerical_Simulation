clc;
clear;
x0=0;
xn=pi/2;
N=39;
i1=Sint(x0,xn,N);
i2=Rint(x0,xn,N);
i3=Dint(x0,xn,N);
ymin=0;
ymax=1;
i4=RanInt(x0,xn,ymin,ymax);
i5=RanMInt(x0,xn);
[i1 i2 i3 i4 i5]
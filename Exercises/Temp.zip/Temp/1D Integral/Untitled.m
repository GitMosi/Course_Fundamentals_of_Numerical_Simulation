clc;
clear;
a = 899;
c = 1;
m = 32000000;
x=12;
N=2000;
y(1)=0;
for i=2:N
    x=mod(a*x+c,m);
    r=x/m;
    z(i-1)=r;
    if r<0.5
        y(i)=y(i-1)+1;
    else
        y(i)=y(i-1)-1;
    end
end
%hist(z,100);
plot(y)
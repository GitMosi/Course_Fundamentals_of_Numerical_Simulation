function y=func(x)
y=cos(x);
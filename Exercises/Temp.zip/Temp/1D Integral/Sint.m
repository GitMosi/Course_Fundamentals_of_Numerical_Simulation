function Y=Sint(x0,xn,N)
%x=linSpace(x0,xn,N);
dx=(xn-x0)/N;
Y=func(x0)+func(xn);
x=x0;
for i=1:N/2-1
    x=x+dx;
    Y=Y+4*func(x);
    x=x+dx;
    Y=Y+2*func(x);
end
Y=Y*dx/3;
function Y=Dint(x0,xn,N)
x=x0;
dx=(xn-x0)/N;
Y=0;
while x<xn
    n=(func(x)+func(x+dx))/2;
    Y=Y+n*dx;
    x=x+dx;
end
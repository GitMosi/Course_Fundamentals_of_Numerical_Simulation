clc;
clear;
x=0;
y=0;
dx=0.01;
while x<pi/2
y=y+cos(x)*dx;
x=x+dx
end
y
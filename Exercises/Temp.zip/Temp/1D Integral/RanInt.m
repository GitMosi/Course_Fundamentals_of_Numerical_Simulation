%function Y=RanInt(x0,xn,ymin,ymax)
N=20;
x0=0;
xn=pi/2;
ymin=0;
ymax=1;
dx=(xn-x0);
dy=(ymax-ymin);
x=rand(1,N).*dx+x0;
y=rand(1,N).*dy+ymin;
scatter(x,y);hold on
m=0;
for i=1:N
    if func(x(i))>y(i)
        m=m+1;
        xp(m)=x(i);
        yp(m)=y(i);
    end
end
scatter(xp,yp,'r');
a=dx*dy;
Y=m*a/N;
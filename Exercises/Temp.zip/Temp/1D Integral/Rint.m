function Y=Rint(x0,xn,N)
%x=linSpace(x0,xn,N);
dx=(xn-x0)/N;
x=x0;
Y=func(x);
for i=1:N-1
    x=x+dx;
    Y=Y+func(x);
end
Y=Y*dx;
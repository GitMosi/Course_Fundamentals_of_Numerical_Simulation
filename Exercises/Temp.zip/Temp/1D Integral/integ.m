clc;
clear;
N=100000;
x=rand(1,N).*pi/2;
y=rand(1,N);
m=0;
for i=1:N
    if cos(x(i))>y(i)
        m=m+1;
        xz(m)=x(i);
        yz(m)=y(i);
    end
end
pi/2*m/N
scatter(xz,yz)
#ifndef INTEGRAL_H
#define INTEGRAL_H
#include <cmath>
#include <stdlib.h>
#include <time.h>

using namespace std;
class Integral
{
    public:
        double a,b,N,s;
        Integral();
        virtual ~Integral();
        void IntegralRec();
        void IntegralTra();
        void IntegralSim();
        void IntegralDif();
        void IntegralRan();
        void IntegralMRan();

    protected:

    private:
        double dx,x;
};

#endif // INTEGRAL_H

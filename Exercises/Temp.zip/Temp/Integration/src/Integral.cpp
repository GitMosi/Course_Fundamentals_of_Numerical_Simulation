#include "Integral.h"

Integral::Integral()
{
    srand(time(NULL));
}

Integral::~Integral()
{
    //dtor
}
double Func(double x)
{
    return cos(x);
}

void Integral::IntegralRec()
{
    dx=(b-a)/N;
    x=a;
    s=0;
    for(int i=0;i<N;i++)
    {
        s+=Func(x);
        x=x+dx;
    }
    s*=dx;
}
void Integral::IntegralTra()
{
    dx=(b-a)/N;
    x=a;
    s=Func(a)/2+Func(b)/2;
    for(int i=0;i<N-2;i++)
    {
        x=x+dx;
        s+=Func(x);
    }
    s*=dx;
}
void Integral::IntegralSim()
{
    dx=(b-a)/N;
    x=a;
    s=Func(a)+Func(b);
    for(int i=0;i<(N-1)/2;i++)
    {
        x=x+dx;
        s+=4*Func(x);
        x=x+dx;
        s=s+2*Func(x);
    }
    s*=dx/3;
}
void Integral::IntegralDif()
{
    dx=(b-a)/N;
    x=a;
    s=0;
    while(x<b)
    {
        s=s+(Func(x)+Func(x+dx))*dx/2;
        x=x+dx;
    }
}

void Integral::IntegralRan()
{
    dx=(b-a);
    int m=0;
    double y=0;
    for(int i=0;i<N;i++)
    {
        x=rand();
        x/=RAND_MAX;
        x=a+(b-a)*x;
        y=rand();
        y/=RAND_MAX;
        if(y<Func(x))
        {
            m+=1;
        }
    }
    s=m*dx*1;
    s/=N;
}

void Integral::IntegralMRan()
{
    dx=(b-a);
    int m=0;
    for(int i=0;i<N;i++)
    {
        x=rand();
        x/=RAND_MAX;
        x=a+(b-a)*x;
        s=s+Func(x);
    }
    s=s*dx/N;
}


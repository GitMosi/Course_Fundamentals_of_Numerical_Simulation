#include <iostream>
#include <Integral.h>

using namespace std;

int main()
{
    Integral integ;
    integ.a=0;
    integ.b=3.14159265358979/2;
    integ.N=20;
    integ.IntegralRec();
    cout << "Rectangular: " << integ.s << endl;
    integ.IntegralTra();
    cout << "Trapizodail: " << integ.s << endl;
    integ.IntegralSim();
    cout << "Simpson: " << integ.s << endl;
    integ.IntegralDif();
    cout << "Diff Equation: " << integ.s << endl;
    integ.N=1000;
    integ.IntegralRan();
    cout << "Random: " << integ.s << endl;
    integ.N=1000;
    integ.IntegralMRan();
    cout << "Mean: " << integ.s << endl;
    return 0;
}

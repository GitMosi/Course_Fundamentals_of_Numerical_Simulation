clc;
clear;
N=10000;
r=rand(1,N);
theta=2*pi.*rand(1,N);
% a=10;b=100;
% x=a+(b-a)*r;
% hist(x,100)
% Landa=1;
% ro=-Landa*log(r);
% hist(x,100)
% s=sqrt(2.*ro);
% x=s.*cos(theta);
% y=s.*sin(theta);
%hist(x,100);
% hist(y,100);
R=1;
r=R.*sqrt(r);
% 
x=r.*cos(theta);
y=r.*sin(theta);
scatter(x,y,'.');axis equal;

function z=func(x,y)
z=-(x.^2+y.^2);
clc;
clear;
%x=-1:.1:1;
x=linspace(-1,1,21);
y=-1:.1:1;
figure(1);
scatter(x,y)
[X,Y]=meshgrid(x,y);
figure(2)
scatter(X(:),Y(:));
Z=func(X,Y);
surfc(X,Y,Z);shading interp;alpha(0.2)
x=rand(1,10);
y=rand(1,10);
z=rand(1,10);
%plot3(x,y,z);
scatter3(x,y,z,'filled');axis equal;
title('3D Plot');
xlabel('X');
figure(3)
contour(X,Y,Z)
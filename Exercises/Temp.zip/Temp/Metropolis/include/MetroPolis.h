#ifndef METROPOLIS_H
#define METROPOLIS_H
#include "time.h"
#include <stdlib.h>
#include <vector>
#include <cmath>

using namespace std;
class MetroPolis
{
    public:
        int N,M;
        vector<double> r;
        MetroPolis(int,int);
        virtual ~MetroPolis();

    protected:

    private:
        double del;
};

#endif // METROPOLIS_H

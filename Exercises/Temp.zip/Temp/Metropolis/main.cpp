#include <iostream>
#include "MetroPolis.h"
#include "TCanvas.h"
//#include "TROOT.h"
//#include "TGraphErrors.h"
//#include "TApplication.h"
//#include <TAxis.h>
#include <TH1F.h>

using namespace std;

int main()
{
    MetroPolis mp(10000,1000);

    TCanvas *c1 = new TCanvas("c1","MetroPolis Gaussian Distribution",800,800);
    auto hist=new TH1F("count_rate",
    "Count Rate;N_{Counts};# occurencies",
    100,-5,5);//, // Number of Bins, Lower X Boundary, Upper X Boundary
    for (int i=0;i<mp.N;i++)
        hist->Fill(mp.r[i]);
    hist->Draw();
    c1->Print("ND.eps");
    return 0;
}

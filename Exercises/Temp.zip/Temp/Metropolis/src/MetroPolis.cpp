#include "MetroPolis.h"

MetroPolis::MetroPolis(int N0, int M0)
{
    N=N0;
    M=M0;
    del=1;
    srand(time(NULL));
    for(int i=0;i<N;i++)
    {
        r.push_back(0);
    }
    double d=0;
    for(int j=0;j<M;j++)
    {
        for(int i=0;i<N;i++)
        {
            d=rand();d/=RAND_MAX;
            d=(2*d-1)*del;
            double r0=(r[i]+d);
            double w=exp(-r0*r0/2+r[i]*r[i]/2);
            if(w>=1)
                r[i]=r0;
            else
            {
                double r1=rand();r1/=RAND_MAX;
                if(r1<=w)r[i]=r0;
            }
        }
    }
}

MetroPolis::~MetroPolis()
{
    //dtor
}

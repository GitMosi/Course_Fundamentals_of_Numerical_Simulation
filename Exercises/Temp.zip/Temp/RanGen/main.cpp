#include <iostream>
#include <fstream>
#include <cstring>
#include <vector>
#include "Time.h"
#include "TCanvas.h"
#include "TROOT.h"
#include "TGraphErrors.h"
#include "TApplication.h"
#include <TAxis.h>
#include <TH1F.h>


using namespace std;

int main()
{
    Time t;
    t.Start();
    int a = 899;
    int c = 1;
    int m = 32000;
    int x=12;
    int N=200;
    double r=0;
    vector<double> xp,y;
    vector<double> z;
    xp.push_back(0);
    y.push_back(0);
    for(int i=1;i<N;i++)
    {
        x=(a*x+c)%m;
        r=x;
        r/=m;
        z.push_back(r);
        xp.push_back(i);
        if(r<0.5)
            y.push_back(y[i-1]+1);
        else
            y.push_back(y[i-1]-1);
    }
    TCanvas *c1 = new TCanvas("c1","Random Numbers",800,800);
    auto hist=new TH1F("count_rate",
    "Count Rate;N_{Counts};# occurencies",
    100,0,1);//, // Number of Bins, Lower X Boundary, Upper X Boundary
    for (int i=0;i<N;i++)
        hist->Fill(z[i]);
    hist->Draw();
    c1->Print("RN.eps");
    delete c1;

    c1 = new TCanvas("c1","1D Random Walk",800,800);
    TGraphErrors gr(N,&xp[0],&y[0]);
    gr.Draw("ALP");
    c1->Print("RW.eps");
//    gr->SetTitle(s.c_str());
//    gr->SetLineColor(2);
//    gr->SetLineWidth(3);
//    gr->SetMarkerColor(4);
//    gr->SetMarkerStyle(4);
//    gr->SetMarkerSize(1);
//    gr->GetXaxis()->SetTitle("X");
//    gr->GetXaxis()->SetLabelFont(42);
//    gr->GetXaxis()->SetTitleSize(0.07);
//    gr->GetXaxis()->SetTitleOffset(0.6);
//    gr->GetXaxis()->SetTitleFont(42);
//    gr->GetYaxis()->SetTitle("Y");
//    gr->GetYaxis()->SetLabelFont(42);
//    gr->GetYaxis()->SetTitleSize(0.07);
//    gr->GetYaxis()->SetTitleOffset(0.7);
//    gr->GetYaxis()->SetTitleFont(42);
//
//    gr->Draw("ALP");

    t.Stop();
    return 0;
}

function s=MontCarloInt
s=0;
N=2000;
x=2.*rand(1,N)-1;
y=2.*rand(1,N)-1;
for i=1:length(x)
    if x(i)^2+y(i)^2<=1
        s=s+func(x(i),y(i));
    end
end
s=4/N*s;
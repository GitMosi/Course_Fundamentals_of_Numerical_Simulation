function z=func(x,y)
z=x.^2+6.*x.*y +y.^2;
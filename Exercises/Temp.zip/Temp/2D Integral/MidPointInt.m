function s=MidPointInt
d=0.05;
x=-1:d:1;
y=-1:d:1;
[X,Y]=meshgrid(x,y);
s=0;
for i=1:size(X,1)
    for j=1:size(Y,2)
        if X(i,j)^2+Y(i,j)^2<=1
            s=s+func(X(i,j),Y(i,j));
        end
    end
end
s=s*d^2;
        
clc;
clear;
i1=MidPointInt;
i2=MontCarloInt;
[i1 i2]
#ifndef MD_H
#define MD_H
#include <ctime>
#include <stdlib.h>
#include <cmath>
#include <iostream>

using namespace std;

struct particle
{
    double x,y,vx,vy,ax,ay;
};
class MD
{
    public:
        int N, steps;
        double lx,ly,t,dt;
        double initialKineticEnergy;
        particle* p;
        MD(int, double, double, double,double);
        virtual ~MD();
        void ComputeAcceleration();
        void Step();
        double getMeanTemperature();
        double getMeanEnergy();
        double getMeanPressure();
        double getHeatCapacity();
        void resetAverages();

    protected:

    private:
        double halfdt, halfdt2, totalKineticEnergyAccumulator,totalKineticEnergySquaredAccumulator,totalPotentialEnergyAccumulator, virialAccumulator;
};

#endif // MD_H

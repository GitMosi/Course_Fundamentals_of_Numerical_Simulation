#include "MD.h"


double pbcSeparation(double, double);
MD::MD(int N0,double lx0, double ly0,double dt0,double iK): N(N0),lx(lx0),ly(ly0), dt(dt0), initialKineticEnergy(iK)
{
    srand(time(NULL));
    p=new particle[N];
    double r;
    bool overlap=false;
    double minDis2=pow(2,1.0/3);
    double dx,dy;
    for(int i=0;i<N;i++)
    {
        do
        {
            overlap=false;
            int j=0;
            r=rand();r/=RAND_MAX;
            p[i].x=r*lx;
            r=rand();r/=RAND_MAX;
            p[i].y=r*ly;
            while(j<i&&!overlap)
            {
                dx=p[i].x-p[j].x;
                dx=pbcSeparation(dx,lx);
                dy=p[i].y-p[j].y;
                dy=pbcSeparation(dy,ly);
                if(dx*dx+dy*dy<minDis2)overlap=true;
                j++;
            }
        }while(overlap);
        //cout << i << "\t" << p[i].x << "\t" << p[i].y << endl;
    }
    double vxs=0,vys=0;
    for(int i=1;i<N;i++)
    {
        r=rand();r/=RAND_MAX;
        r=r-0.5;
        p[i].vx=r;
        vxs+=p[i].vx;
        r=rand();r/=RAND_MAX;
        r=r-0.5;
        p[i].vy=r;
        vys+=p[i].vy;
    }
    vxs/=N;
    vys/=N;
    for(int i=1;i<N;i++)
    {
        p[i].vx-=vxs;
        p[i].vy-=vys;
    }
    double vs2=0;
    for(int i=1;i<N;i++)
    {
        vs2+=p[i].vx*p[i].vx+p[i].vy*p[i].vy;
    }
    double KinEn=0.5*vs2/N;
    double rescale =sqrt(initialKineticEnergy/KinEn);
    for ( int i = 0; i<N;i++)
    {
        p[i].vx*=rescale;
        p[i].vy*=rescale;
    }
    totalPotentialEnergyAccumulator=0;
    virialAccumulator=0;
    halfdt= 0.5* dt;
    halfdt2 = 0.5*dt*dt;
    ComputeAcceleration();
    steps=0;
    totalKineticEnergyAccumulator=0;
    totalKineticEnergySquaredAccumulator=0;
    totalPotentialEnergyAccumulator=0;
    virialAccumulator=0;
    t=0;
//    for ( int i = 0; i<N;i++)
//    cout << i << "\t" << p[i].ax << "\t" << p[i].ay << endl;
}

MD::~MD()
{
    //dtor
}

double PbcPosition(double s, double L)//Periodic Boundary Position
{
    return s<0?fmod(s,L)+L:fmod(s,L);
}

double pbcSeparation (double ds, double L)//Periodic Boundary Separation
{
    if(ds>0.5*L)
    {
        ds-=L;
    }
    else if(ds<-0.5*L)
    {
        ds+=L;
    }
    return ds;
}
void MD::ComputeAcceleration()
{
	for( int i = 0; i<N; i ++)
	{
		p[i].ax=0;
		p[i].ay=0;
	}

	for(int i=0; i<N-1;i++)
	{
		for(int j=i+1; j<N; j++)
		{
			double dx = pbcSeparation(p[i].x-p[j].x,lx);
			double dy = pbcSeparation(p[i].y-p[j].y,ly);
			double r2 = dx*dx+dy*dy;
			double oneOverR2 = 1.0/ r2 ;
			double oneOverR6 = oneOverR2*oneOverR2*oneOverR2;
			double fOverR = 48.0*oneOverR6*(oneOverR6-0.5)*oneOverR2;
			double fx=fOverR*dx;
			double fy=fOverR*dy;
			p[i].ax+=fx;
			p[i].ay+=fy;
			p[j].ax-=fx;
			p[j].ay-=fy;
			totalPotentialEnergyAccumulator += 4.0 * ( oneOverR6*oneOverR6-oneOverR6 );
			virialAccumulator += dx*fx+dy*fy;
		}
	}
}

void MD::Step()
{
    for(int i=0;i<N;i++)
    {
        // use old acceleration
        p[i].x += p[i].vx * dt + p[i].ax * halfdt2; // halfdt2 = 0.5* dt * dt
        p[i].y += p[i].vy * dt + p[i].ay * halfdt2;
        p[i].vx += p[i].ax * halfdt; // add old acceleration , halfdt= 0.5* dt
        p[i].vy += p[i].ay * halfdt;
    }
    // computes velocity in two steps using old and new acceleration
    ComputeAcceleration();
    for(int i=0;i<N;i++)
    {
        // add new acceleration
        p[i].vx += p[i].ax*halfdt;
        p[i].vy += p[i].ay*halfdt;
    }
    double totalKineticEnergy = 0 ;
    for (int i=0;i<N; i++)
    {
        totalKineticEnergy +=  (p[i].vx*p[i].vx+ p[i].vy*p[i].vy) ;
        p[i].x= PbcPosition(p[i].x,lx);
        p[i].y= PbcPosition(p[i].y,ly);
    }
    totalKineticEnergy*=0.5;
    steps++;
    totalKineticEnergyAccumulator+=totalKineticEnergy ;
    totalKineticEnergySquaredAccumulator += totalKineticEnergy * totalKineticEnergy;
    t+=dt;
}

double MD::getMeanTemperature()
{
	return totalKineticEnergyAccumulator/(N* steps) ;
}
double MD::getMeanEnergy()
{
	return totalKineticEnergyAccumulator/ steps+totalPotentialEnergyAccumulator/steps;
}
double MD::getMeanPressure()
{
	double meanVirial;
	meanVirial = virialAccumulator/ steps;
	// quantity PA/NkT
	return 1.0+0.5*meanVirial/(N*getMeanTemperature());
}
double MD::getHeatCapacity()
{
	double meanTemperature = getMeanTemperature();
	double meanTemperatureSquared = totalKineticEnergySquaredAccumulator/ steps;
	// heat capacity related to fluctuations of kinetic energy
	double sigma2 = meanTemperatureSquared-meanTemperature *meanTemperature ;
	double denom = sigma2 / (N*meanTemperature *meanTemperature ) - 1.0;
	return N/denom;
}
void MD::resetAverages()
{
	steps= 0;
	virialAccumulator= 0;
	totalPotentialEnergyAccumulator = 0;
	totalKineticEnergyAccumulator = 0;
	totalKineticEnergySquaredAccumulator= 0;
}


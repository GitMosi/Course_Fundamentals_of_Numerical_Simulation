#include <iostream>
#include <cmath>
#include "MD.h"
#include "TCanvas.h"
#include "TGraphErrors.h"
#include <TAxis.h>
#include <TMultiGraph.h>

using namespace std;

int main()
{
    int N=64;
    double lx=11,ly=11,dt=0.01, initialKineticEnerg=1.0;
    MD md(N,lx,ly,dt,initialKineticEnerg);

    TCanvas *c1 = new TCanvas("c1","Molecular Dynamics",800,800);
    TMultiGraph *mg = new TMultiGraph();
    double x[N],y[N];
    for(int i=0;i<N;i++)
    {
        x[i]=md.p[i].x;
        y[i]=md.p[i].y;
    }
    TGraphErrors * gr1=new TGraphErrors(N,x,y);
    gr1->SetMarkerColor(2);
    gr1->SetMarkerStyle(4);
    gr1->SetMarkerSize(1);
    mg->Add(gr1);


    while(md.steps<100000)
    {
        md.Step();
        //cout << md.t << endl;
    }

    cout << md.getMeanTemperature() << endl;
    cout << md.getMeanPressure() << endl;
    cout << md.getHeatCapacity() << endl;
    cout << md.getMeanEnergy() << endl;

    for(int i=0;i<N;i++)
    {
        x[i]=md.p[i].x;
        y[i]=md.p[i].y;
    }
    TGraphErrors * gr2=new TGraphErrors(N,x,y);
    gr2->SetMarkerColor(4);
    gr2->SetMarkerStyle(4);
    gr2->SetMarkerSize(1);
    mg->Add(gr2);
    mg->Draw("AP");
    c1->Print("RW.eps");

    return 0;
}

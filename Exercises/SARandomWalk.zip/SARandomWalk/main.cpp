#include <iostream>
#include "RW.h"
#include "TCanvas.h"
#include "TROOT.h"
#include "TGraphErrors.h"
#include "TApplication.h"
#include <TAxis.h>

using namespace std;

int main()
{
    int M=0;
    RW* rw;
    vector<double> x,y;
    for(int n=0;n<100000;n++)
    {
        rw=new RW();
        while(!rw->fail)
        {
            rw->Step();
        }
        if(M<rw->nSuccess)
        {
            x.clear();
            y.clear();
            for(int i=0;i<rw->nSuccess;i++)
            {
                x.push_back(rw->x[i]);
                y.push_back(rw->y[i]);
            }
            M=rw->nSuccess;
            cout << M << endl;
            delete rw;
        }
    }
    cout << M << endl;
    TCanvas *c1 = new TCanvas("c1","Self Avoiding Random Walk",800,800);
    TGraphErrors * gr=new TGraphErrors(M,&x[0],&y[0]);
    string s="Self Avoiding Random Walk. Numer of steps: "+to_string(M);
    gr->SetTitle(s.c_str());
    gr->SetLineColor(2);
    gr->SetLineWidth(3);
    gr->SetMarkerColor(4);
    gr->SetMarkerStyle(4);
    gr->SetMarkerSize(1);
    gr->GetXaxis()->SetTitle("X");
    gr->GetXaxis()->SetLabelFont(42);
    gr->GetXaxis()->SetTitleSize(0.07);
    gr->GetXaxis()->SetTitleOffset(0.6);
    gr->GetXaxis()->SetTitleFont(42);
    gr->GetYaxis()->SetTitle("Y");
    gr->GetYaxis()->SetLabelFont(42);
    gr->GetYaxis()->SetTitleSize(0.07);
    gr->GetYaxis()->SetTitleOffset(0.7);
    gr->GetYaxis()->SetTitleFont(42);

    gr->Draw("ALP");
    c1->Print("RW.eps");

    return 0;
}

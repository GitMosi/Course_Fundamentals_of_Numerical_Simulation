#ifndef RW_H
#define RW_H
#include <vector>
#include <cstdlib>
#include <time.h>
#include <iostream>
#include <TRandom3.h>

using namespace std;
class RW
{
    public:
        int delX, delY,nSuccess;
        bool fail;
        vector<int> x,y;
        RW();
        virtual ~RW();
        void Step();

    protected:

    private:
        int Rand, ran[3], step[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
};

#endif // RW_H

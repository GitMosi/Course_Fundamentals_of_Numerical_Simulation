#include "RW.h"

RW::RW()
{
    //srand(time(NULL));
    //srand(1);
    gRandom = new TRandom3(0);
    delX=1;delY=1;
    x.push_back(0);
    y.push_back(0);
    x.push_back(1);
    y.push_back(0);
    step[0][0]*=delX;
    step[1][0]*=delX;
    step[2][1]*=delY;
    step[3][1]*=delY;
    Rand=0;
    ran[0]=-1;
    ran[1]=-1;
    ran[2]=-1;
    nSuccess=2;
    fail=false;
}

RW::~RW()
{
    x.clear();
    y.clear();
}
bool Check(vector<int> x,vector<int> y,int xi,int yi)
{
    bool b=true;
    for(int i=0;i<x.size();i++)
    {
        if(x[i]==xi&&y[i]==yi)
        {
            b=false;
        }
    }
    return b;
}
bool CheckReverse(int r,int Rand)
{
    bool b=(r==0)&&Rand==1;
    b=b||(r==1)&&Rand==0;
    b=b||(r==2)&&Rand==3;
    b=b||(r==3)&&Rand==2;
    return b;
}
void RW::Step()
{
    int r;
    bool b;
    int i=0;
    do
    {
        r=gRandom->Integer(4);
        b=CheckReverse(r,Rand);
    }while(b);
    ran[0]=r;
    do
    {
        //r=rand()%4;
        r=gRandom->Integer(4);
        b=CheckReverse(r,Rand);
    }while(b||r==ran[0]);
    ran[1]=r;
    do
    {
        //r=rand()%4;
        r=gRandom->Integer(4);
        b=CheckReverse(r,Rand);
    }while(b||r==ran[0]||r==ran[1]);
    ran[2]=r;

    int n=x.size();
    if(Check(x,y,x[n-1]+step[ran[0]][0],y[n-1]+step[ran[0]][1]))
    {
        x.push_back(x[n-1]+step[ran[0]][0]);
        y.push_back(y[n-1]+step[ran[0]][1]);
        nSuccess++;
        Rand=ran[0];
    }
    else if(Check(x,y,x[n-1]+step[ran[1]][0],y[n-1]+step[ran[1]][1]))
    {
        x.push_back(x[n-1]+step[ran[1]][0]);
        y.push_back(y[n-1]+step[ran[1]][1]);
        nSuccess++;
        Rand=ran[1];
    }
    else if(Check(x,y,x[n-1]+step[ran[2]][0],y[n-1]+step[ran[2]][1]))
    {
        x.push_back(x[n-1]+step[ran[2]][0]);
        y.push_back(y[n-1]+step[ran[2]][1]);
        nSuccess++;
        Rand=ran[2];
    }
    else
    {
        fail=true;
        //cout << ran[0] << "\t" << ran[1] << "\t" << ran[2] << "\t" << Rand << "\t" << r << endl;
    }
}

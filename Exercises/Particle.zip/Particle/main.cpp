#include <iostream>
#include <Particle.h>
#include <FallingParticle.h>
#include <vector>
#include "TCanvas.h"
#include "TMultiGraph.h"
#include "TGraphErrors.h"
#include "TAxis.h"
#include "TROOT.h"
#include "TApplication.h"

using namespace std;

void macro()
{
    TCanvas *c1 = new TCanvas("c1","multigraph");
	c1->SetGrid();
	TMultiGraph *mg = new TMultiGraph();
	vector<double> xPath,tPath;

    double x0 = 0, v0 = 10, t0=0, dtp = 0.2;
    cout << "Euler Method / Pointer of Parent--------------------------------------------------\n";
    Particle * par;
    par=new FallingParticle(x0,v0);
    par->t=t0;
    par->dt=dtp;
    do
    {
        tPath.push_back(par->t);
        xPath.push_back(par->x);
        par->Step();
    }while(par->x>0);
    tPath.push_back(par->t);
    xPath.push_back(par->x);
    TGraphErrors *gr1 = new TGraphErrors(xPath.size(),&tPath[0],&xPath[0]);
    gr1->SetLineWidth(3);
	gr1->SetLineColor(kBlue);
	mg->Add(gr1);

	for(int i=0;i<xPath.size();i++)
    {
        par->t=tPath.at(i);
        xPath.at(i)=par->AnalyticPosition();
    }
    TGraphErrors *gr2 = new TGraphErrors(xPath.size(),&tPath[0],&xPath[0]);
    gr2->SetLineWidth(3);
	gr2->SetLineColor(kBlack);
	mg->Add(gr2);

    tPath.clear();
    xPath.clear();

    delete par;

    cout << "Euler-Cramers Method / Pointer of Parent------------------------------------------\n";
    par=new FallingParticleEC(x0,v0);
    par->t=t0;
    par->dt=dtp;
    do
    {
        tPath.push_back(par->t);
        xPath.push_back(par->x);
        par->Step();
    }while(par->x>0);
    tPath.push_back(par->t);
    xPath.push_back(par->x);
    TGraphErrors *gr3 = new TGraphErrors(xPath.size(),&tPath[0],&xPath[0]);
    gr3->SetLineWidth(3);
	gr3->SetLineColor(kRed);
	mg->Add(gr3);
    tPath.clear();
    xPath.clear();

    delete par;

    cout << "Euler-Richardson Method / Pointer of Parent---------------------------------------\n";
    par=new FallingParticleER(x0,v0);
    par->t=t0;
    par->dt=dtp;
    do
    {
        tPath.push_back(par->t);
        xPath.push_back(par->x);
        par->Step();
    }while(par->x>0);
    tPath.push_back(par->t);
    xPath.push_back(par->x);
    TGraphErrors *gr4 = new TGraphErrors(xPath.size(),&tPath[0],&xPath[0]);
    gr4->SetLineWidth(3);
	gr4->SetLineColor(kGreen);
	mg->Add(gr4);

    tPath.clear();
    xPath.clear();

    mg->Draw("a");
	mg->GetXaxis()->SetTitle("Time (s)");
	mg->GetYaxis()->SetTitle("Y (m)");
	gPad->Update();
	gPad->Modified();
	c1->Print("graph_with_law.eps");

    delete par;
}

void StandaloneApplication(int argc, char** argv)
{
	// eventually, evaluate the application parameters argc, argv
	// ==>> here the ROOT macro is called
	macro();
}

int main(int argc, char** argv)
{
	TApplication app("ROOT Application", &argc, argv);
	StandaloneApplication(app.Argc(), app.Argv());
	app.Run();
	return 0;
}

#ifndef COMPLEX_H
#define COMPLEX_H
#include <cmath>
#include <iostream>
class Complex
{
    private:
        double x,y;
    public:
        Complex();
        Complex(double, double);
        virtual ~Complex();
        Complex operator+(const Complex&);
        Complex operator-(const Complex&);
        Complex operator*(const Complex&);
        Complex operator/(const Complex&);
        void ChangeValues(double,double);
        void ShowNumber();
        double Argument();
        double ABS();
    protected:
};

#endif // COMPLEX_H

#include "Complex.h"

Complex::Complex()
{
    //ctor
}

Complex::~Complex()
{
    //dtor
}
Complex::Complex(double xt, double yt)
{
    x=xt;
    y=yt;
}
Complex Complex::operator+(const Complex& param)
{
    Complex temp;
    temp.x=x+param.x;
    temp.y=y+param.y;
    return temp;
}
Complex Complex::operator-(const Complex& param)
{
    Complex temp;
    temp.x=x-param.x;
    temp.y=y-param.y;
    return temp;
}
Complex Complex::operator*(const Complex& param)
{
    Complex temp;
    temp.x=x*param.x-y*param.y;
    temp.y=x*param.y+y*param.x;
    return temp;
}
Complex Complex::operator/(const Complex& param)
{
    double tp=param.x*param.x+param.y*param.y;
    Complex temp;
    temp.x=x*param.x+y*param.y;
    temp.x/=tp;
    temp.y=-x*param.y+y*param.x;
    temp.y/=tp;
    return temp;
}
double Complex::ABS()
{
    double r=sqrt(x*x+y*y);
    return r;
}
double Complex::Argument()
{
    double th=atan2(y,x);
    return th;
}
void Complex::ChangeValues(double xt,double yt)
{
    x=xt;
    y=yt;
}

void Complex::ShowNumber()
{
    if(y>=0)
    std::cout << x << " + " << y << "i" << std::endl;
    else
    std::cout << x << " - " << -y << "i" << std::endl;
}

#include <iostream>
#include "Complex.h"

using namespace std;

int main()
{
    Complex a(1,2), b, c;
    b.ChangeValues(2,3);
    c=a+b;
    c.ShowNumber();
    c=a-b;
    c.ShowNumber();
    c=a*b;
    c.ShowNumber();
    c=a/b;
    c.ShowNumber();
    cout << a.Argument()*180/M_PI << endl;
    cout << a.ABS() << endl;
    return 0;
}
